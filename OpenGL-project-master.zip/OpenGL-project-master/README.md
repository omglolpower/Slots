# movement_with_boundaries
# Opengl 3.0+, glfw, glew, fment shaders, vtex shaders, move bleaking circle with arrows

# a visual studio project should be created using template Default OpenGL project upd4
# shaders folder shoud be in C:\\dev
# Dependencies folder should be in solution directory

  
Move a bleaking circle inside 1280x720 window using arrow keys. Boundaries are borders of the window.
circles change the color gradually.  
upd1: now it's a game Eat Circles. You move a big circle and "eat" small ones (https://youtu.be/uQKjshqH13E).  
upd2: added hit sound (PlaySound) (https://youtu.be/mPsQvKmvcWs).  
upd3: now it's Shoot circles (https://youtu.be/nU0aaa26NyI).  
upd4: Added hit counter: a hexagon is drawn when circle is hit (https://youtu.be/DwZW59aAXGM).  
upd5: Hit counter draws digits (https://youtu.be/pOu4aT2FsW0).  
upd6: Modified the hit counter: the hit counter draws all numbers (0 -- inf) (https://youtu.be/osVphSgLV80).
